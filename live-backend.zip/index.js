import express from 'express';
import cors from 'cors';
import moodRoutes from './routes/mood.js';
import recRoutes from './routes/recommendations.js';

const app = express();
app.use(cors());
app.use(express.json());

app.use('/api/mood', moodRoutes);
app.use('/api/recommendations', recRoutes);

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log('Server running on port', PORT));