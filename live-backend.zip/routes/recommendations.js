import { Router } from 'express';

const router = Router();

router.get('/', (req, res) => {
  const mood = (req.query.mood || '').toLowerCase();
  // dummy recs
  const recs = {
    music: ['Weightless – Marconi Union', 'Golden Hour – JVKE'],
    food: ['Sushi', 'Thai Green Curry'],
    mantra: 'With our thoughts we make the world.'
  };
  res.json(recs);
});

export default router;