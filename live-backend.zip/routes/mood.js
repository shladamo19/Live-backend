import { Router } from 'express';

const router = Router();

const colorMap = {
  happy: '#ffeb3b',
  calm: '#00bcd4',
  focused: '#ff9800',
  loving: '#e91e63',
  sad: '#3f51b5',
  angry: '#f44336'
};
const energyMap = {
  happy: 'High',
  calm: 'Medium',
  focused: 'Sharp',
  loving: 'Radiant',
  sad: 'Low',
  angry: 'Chaotic'
};

router.post('/', (req, res) => {
  const { current, target } = req.body;
  const mood = (target || current || '').toLowerCase();
  res.json({
    color: colorMap[mood] || '#673ab7',
    energy: energyMap[mood] || 'Unknown'
  });
});

export default router;